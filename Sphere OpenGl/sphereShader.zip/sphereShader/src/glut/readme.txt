It contains GLUT header (glut.h) and static library (libglut32.a) files for
MinGW GNU compiler (Windows only). Use it for Code::Blocks projects. These
files are extracted from glut.3.7.6+.DevPak for DevC++ IDE.

Source: http://www.nigels.com/glt/devpak/glut.3.7.6+.DevPak
